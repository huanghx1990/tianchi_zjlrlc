
- long-tailed distributions for all users
![](https://github.com/wepe/weibo/blob/master/plot/figure_1.png)

- for single user

![](https://github.com/wepe/weibo/blob/master/plot/figure_13.png)

![](https://github.com/wepe/weibo/blob/master/plot/figure_7.png)

![](https://github.com/wepe/weibo/blob/master/plot/figure_3.png)
