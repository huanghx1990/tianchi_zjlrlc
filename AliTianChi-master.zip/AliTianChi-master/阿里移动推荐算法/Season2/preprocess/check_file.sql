--select count(*) from prj_tianchi_1_602_dev.jiagwc18;

--select * from prj_tianchi_1_602_dev.test ;
--select distinct user_id,item_id from prj_tianchi_1_602_dev.tianchi_mobile_recommendation_predict;
select count(*) from prj_tianchi_1_602_dev.tianchi_mobile_recommendation_predict1;
--select count(*) from tianchi_lbs.tianchi_mobile_recommend_train_user;
--select count(*) from tianchi_lbs.tianchi_mobile_recommend_train_item;